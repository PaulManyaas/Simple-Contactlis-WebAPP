# PAUL MANYAAS WELTEL PROGRAMMING ASESSMENT- Contact List WebApp
<h2>Paul Manyaas - Simple Contact List App</h2>


This repo contains the code for a RESTful API Simple Contact List App that was built using nodejs angular js and MongoDB.

#You need the following installed properly:
<ul>
<li>MongoDB</li>
<li>Express</li>
<li>AngularJS</li>
<li>NodeJS</li>
</ul>


<h3>Instructions</h3>

Github code available at

    

then install the Node modules with

    npm install
     npm install express
     npm install mongojs
    

then make sure MongoDB is running with
cd ..
to the mongo files on bin folder
    mongod

from your MongoDB directory, and then run the code with 

    node server

You will see a message that says, 

   Server running on port 3000
    


<h3>Open on the browser : localhost:3000</h3>

#The App should be running properly!!!
#Have fun!!!
#From**** Paul Manyaas

#If you have any questions, feel free to ask I will try to help.
